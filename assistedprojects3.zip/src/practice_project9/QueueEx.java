package practice_project9;

import java.util.LinkedList;
import java.util.Queue;

public class QueueEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<String> Q1 = new LinkedList<>();
		Q1.add("Madhu");
		Q1.add("Ravi");
		Q1.add("Maxi");
		Q1.add("Rahul");
		Q1.add("Nani");
		System.out.println("Queue is : " + Q1);
		System.out.println("Head of Queue : " + Q1.peek());
		Q1.remove();
		System.out.println("After removing Head of Queue : " + Q1);
		System.out.println("Size of Queue : "+ Q1.size());


	}

}
