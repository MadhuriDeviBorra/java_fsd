package practice_project8;

public class StackEx {
	static final int MAX = 1000; 
	int top; 
	int a[] = new int[MAX];  
	boolean isEmpty() 
	{ 
    		return (top < 0); 
	} 
	StackEx() 
	{ 
    		top = -1; 
	} 
	boolean push(int x) 
	{ 
    	if (top>=(MAX-1)) 
    		{ 
        		System.out.println("Stack Overflow"); 
        		return false; 
    		} 
    		else
    		{ 
        		a[++top] =x; 
        		System.out.println(x + " pushed into the stack"); 
        		return true; 
    		} 
	} 
int pop() 
	{ 
    	if (top<0) 
    	{ 
        	System.out.println("Stack Underflow"); 
        	return 0; 
    		} 
    	else
    	{ 
        	int x =a[top--]; 
        	return x; 
    	} 
	} 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackEx st = new StackEx(); 
		st.push(50); 
		st.push(100); 
		st.push(130); 
		System.out.println(st.pop() + " Popped from the stack"); 


	}

}
