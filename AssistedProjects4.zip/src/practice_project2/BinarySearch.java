package practice_project2;

public class BinarySearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] ={10,20,30,23,40,50,7};

		int key =50;

		int indexOfKey = binarySearch(arr,0,arr.length,key);

		if (indexOfKey != -1)
			System.out.println(key + " was found in index position " + indexOfKey);
		else
			System.out.println(key + " was not found");
	}


	static int binarySearch(int[] arr,int start, int end,int key) {

		int midValue=(start + end)/2;

		while (start<=end) {

			if (key>arr[midValue]) {
				start=midValue + 1;				
			}
			else
			if (arr[midValue]==key)
				return midValue;
			else  {
				end=midValue -1;
			}
			;

			midValue =(start + end)/2;

		}

		return -1;

	
	}

}
