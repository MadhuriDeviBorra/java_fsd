package practice_project1;

public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a='M';
		int b=a;
		float c=a;
		long d=a;
		double e=a;
		System.out.println("IMPLICIT TYPE CASTING");
		System.out.println("the value of a="+a);
		System.out.println("the value of b="+b);
		System.out.println("the value of c="+c);
		System.out.println("the value of d="+d);
		System.out.println("the value of e="+e);
		double x=25.5;
		int y=(int)x;
		System.out.println("EXPLICIT TYPE CASTING");
		System.out.println("the value of x="+x);
		System.out.println("the value of y="+y);
		
	}

}
