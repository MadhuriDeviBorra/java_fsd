package practice_project3;

public class OverlodingMethod {
	public void area(int l,int b,int h)
	{
		System.out.println("area of triangle "+(0.5)*(l*b*h));
	}
	public void area(int r)
	{
		System.out.println("area of circle "+(3.14)*(r*r));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OverlodingMethod ovl=new OverlodingMethod();
		ovl.area(2,2,2);
		ovl.area(3);

	}

}
