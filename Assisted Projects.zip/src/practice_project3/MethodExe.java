package practice_project3;

public class MethodExe {
	public int add(int a,int b)
	{
		int x=a+b;
		return x;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodExe m1=new MethodExe();
		int sum=m1.add(2, 3);
		System.out.println("addition of two numbers is "+sum);
	}

}
