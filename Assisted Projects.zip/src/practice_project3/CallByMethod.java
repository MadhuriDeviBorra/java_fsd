package practice_project3;

public class CallByMethod {
	
		int num=10;
		int operation(int num)
		{
			num=num*10/100;
			return(num);
		}
		public static void main(String[] args) {
			CallByMethod m2=new CallByMethod();
			System.out.println("before operation number is "+m2.num);
			m2.operation(100);
			System.out.println("after operation number is "+m2.num);
		}
}
