/**
 * 
 */
/**
 * 
 */
module assistedproj {
}