package practice_project2;

public class AcessSpecifiers3  extends ProtectedAcessSpecifier{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AcessSpecifiers3 obj=new AcessSpecifiers3();
		obj.display();

	}

}
