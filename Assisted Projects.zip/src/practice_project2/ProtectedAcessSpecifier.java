package practice_project2;

public class ProtectedAcessSpecifier {
	protected void display()
	{
		System.out.println("protected acess specifier");
		
	}
}
