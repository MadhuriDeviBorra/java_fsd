package practice_project2;

public class PublicAcessSpecifier {
		public void diplay()
		{
			System.out.println("public acess specifier");
		}
}
