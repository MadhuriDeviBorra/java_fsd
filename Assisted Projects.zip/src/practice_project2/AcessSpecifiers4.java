package practice_project2;

public class AcessSpecifiers4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PublicAcessSpecifier obj = new PublicAcessSpecifier(); 
        obj.diplay();  


	}

}
