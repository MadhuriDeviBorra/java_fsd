package practice_project2;
class PrivateAcessSpecifier
{
	private void display()
	{
		System.out.println("private acess specifier");
	}
	
}

public class AccessSpecifiers2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("this is private access specifier");
		 PrivateAcessSpecifier privateobj = new  PrivateAcessSpecifier();

	}

}
