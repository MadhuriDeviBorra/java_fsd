package practice_project4;
class StudentInfo
{
	int id;
	String name;
	void display()
	{
		System.out.println(id+" "+name);
	}
}

public class DefaultConstructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentInfo st=new StudentInfo();
		st.display();
	}

}
