package practice_project5;

import java.util.*;

public class Collections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("ArrayList");
		ArrayList<String> name=new ArrayList<String>();
		name.add("Maxi");
		name.add("Kushi");
		name.add("Ravi");
		System.out.println(name);
		System.out.println("Vector");
		Vector<Integer> val=new Vector();
		val.add(50);
		val.add(100);
		val.add(150);
		System.out.println(val);
		System.out.println("LinkedList");
		LinkedList<String> city=new LinkedList<String>();
		city.add("hyd");
		city.add("chennai");
		city.add("bangalore");
		System.out.println(city);
		System.out.println("hashset");
		HashSet<Integer> set=new HashSet<Integer>();
		set.add(5);
		set.add(10);
		set.add(15);
		System.out.println(set);
		System.out.println("LinkedHashset");
		LinkedHashSet<Integer> set1=new LinkedHashSet<Integer>();
		set1.add(50);
		set1.add(100);
		set1.add(150);
		System.out.println(set1);
		

	}

}
