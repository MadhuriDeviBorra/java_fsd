package practice_project8;

public class Bike {
	String name;
	int speed;
	int price;
	String color;
	

	public Bike(String name, int speed, int price, String color) {
		super();
		this.name = name;
		this.speed = speed;
		this.price = price;
		this.color = color;
	}
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getspeed() {
		return speed;
	}


	public void setModel(int speed) {
		this.speed = speed;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	@Override
	public String toString() {
		return "Bike [name=" + name + ", speed=" + speed + ", price=" + price + ", color=" + color + "]";
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bike bobj=new Bike("royal enfield",200,150000,"black");
		System.out.println(bobj.toString());
		

	}

}
