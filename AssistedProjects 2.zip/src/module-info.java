/**
 * 
 */
/**
 * 
 */
module assistedprojects2 {
}