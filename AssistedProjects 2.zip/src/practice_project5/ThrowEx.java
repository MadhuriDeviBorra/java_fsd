package practice_project5;

public class ThrowEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=50,b=0,r;

        try
        {
            if(b==0)        
                throw(new ArithmeticException("Can't divide by zero."));
            else
            {
                r = a / b;
                System.out.println("The result is : " + r);
            }
        }
        catch(ArithmeticException Ex)
        {
            System.out.println("Error : " + Ex.getMessage());
        }

        System.out.println("End of program.");
    

	}

}
