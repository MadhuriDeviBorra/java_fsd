package practice_project1;

public class MyThreads extends Thread{
	public void run()
 	{
  		System.out.println("concurrent thread ");
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyThreads mt = new  MyThreads();
  		mt.start();
 	}


	}