package practice_project4;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = new int[10];
        try 
        {
            arr[11] = 3;
        }
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("Array index is out of bounds!"); 
        }
        finally 
        {
            System.out.println("The array is of size " + arr.length);
        }
   

	}

}
